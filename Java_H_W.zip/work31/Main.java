package com.alfa.work3;

public class Main {
    public static void main(String[] args) {
        System.out.println(" xxx     x     x       x     x ");
        System.out.println("   x    x x     x     x     x x");
        System.out.println("   x   x   x     x   x     x   x");
        System.out.println("x  x  xxxxxxx     x x     xxxxxxx");
        System.out.println("xxxx  x     x      x      x     x ");
    }

}
