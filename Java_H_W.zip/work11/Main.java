package com.alfa.work1;

public class Main {

   public static void main(String [] args) {
       System.out.println("Гори в аду, вражина");
   }

}
